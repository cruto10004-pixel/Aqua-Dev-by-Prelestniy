/* Short, interruptible compositor animations. No layout animation or persistent layers. */
const AquaMotion = (() => {
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const running = new Set();
  let enabled = true;
  const easing = 'cubic-bezier(.2,.8,.2,1)';
  function play(node, frames, duration = 200, delay = 0) {
    if (!node || !enabled || reduce.matches || !node.animate) return Promise.resolve();
    for (const active of running) {
      if (active.effect?.target === node || !active.effect?.target?.isConnected) active.cancel();
    }
    const animation = node.animate(frames, {duration, delay, easing, fill:'backwards'});
    running.add(animation);
    return animation.finished.catch(() => {}).finally(() => running.delete(animation));
  }
  function enter(node, kind='page') {
    if(kind==='slide')return play(node,[{opacity:.3,transform:'translateX(28px)'},{opacity:1,transform:'none'}],240);
    const distance={page:6,dialog:8,sheet:8,content:4,message:4}[kind]||4;
    const duration={page:210,dialog:210,sheet:190,content:190,message:170}[kind]||190;
    return play(node,[{opacity:0,transform:`translateY(${distance}px)`},{opacity:1,transform:'none'}],duration);
  }
  function setEnabled(value) {
    enabled = value;
    if (!enabled || reduce.matches) for (const a of running) a.cancel();
  }
  reduce.addEventListener('change', () => setEnabled(enabled));
  return {play, enter, setEnabled};
})();
